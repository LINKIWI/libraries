// Package proton defines clients, constants, and network abstractions for transacting with an HTTP
// server that is API-compliant with Supercharged conventions.
package proton

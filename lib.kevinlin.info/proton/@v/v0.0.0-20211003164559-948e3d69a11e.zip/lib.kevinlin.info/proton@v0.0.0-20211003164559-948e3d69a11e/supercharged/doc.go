// Package supercharged contains Supercharged protocol data structures and usage abstractions.
package supercharged

// Package logger provides abstractions for logging metrics emissions.
package logger

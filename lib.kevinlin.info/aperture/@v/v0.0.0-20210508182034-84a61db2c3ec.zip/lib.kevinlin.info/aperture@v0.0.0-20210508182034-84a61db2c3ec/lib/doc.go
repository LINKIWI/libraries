// Package lib provides general-purpose instrumentation utilities, intended to be consumed by
// library clients.
package lib

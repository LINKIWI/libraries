// Package errors provides abstractions for creating, formatting, and stacking errors.
package errors

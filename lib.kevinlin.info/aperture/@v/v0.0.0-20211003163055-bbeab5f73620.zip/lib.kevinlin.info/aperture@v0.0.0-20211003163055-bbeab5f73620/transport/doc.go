// Package transport provides networking abstractions for unidirectional transports capable of
// sending arbitrary binary message payloads over the wire.
package transport

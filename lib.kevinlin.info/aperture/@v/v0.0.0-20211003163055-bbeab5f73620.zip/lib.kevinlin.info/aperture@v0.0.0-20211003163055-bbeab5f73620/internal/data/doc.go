// Package data provides utilities for manipulating various data primitives and structures.
package data

// Package protocol defines constants and structs related to the statsd protocol specification. It
// additionally provides implementations of logic layers for creating protocol-compliant data
// payloads.
package protocol

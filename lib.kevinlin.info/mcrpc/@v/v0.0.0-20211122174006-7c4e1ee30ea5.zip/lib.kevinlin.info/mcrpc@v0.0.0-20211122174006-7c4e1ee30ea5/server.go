package mcrpc

import (
	"context"
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"lib.kevinlin.info/mcrpc/internal/server"
	"lib.kevinlin.info/mcrpc/protocol"
)

// Option is a type alias for a server option.
type Option func(s *Server) *Server

// Server is a memcache protocol server.
type Server struct {
	handler          Handler
	connReadTimeout  time.Duration
	connWriteTimeout time.Duration
	errorLog         *log.Logger
}

// NewServer creates a new server backed by a Handler.
func NewServer(handler Handler, opts ...Option) (*Server, error) {
	s := &Server{
		handler:  handler,
		errorLog: log.New(io.Discard, "", 0),
	}

	for _, opt := range opts {
		s = opt(s)
	}

	return s, nil
}

// WithConnReadTimeout sets a timeout for all reads on client connections.
func WithConnReadTimeout(timeout time.Duration) Option {
	return func(s *Server) *Server {
		s.connReadTimeout = timeout
		return s
	}
}

// WithConnWriteTimeout sets a timeout for all writes on client connections.
func WithConnWriteTimeout(timeout time.Duration) Option {
	return func(s *Server) *Server {
		s.connWriteTimeout = timeout
		return s
	}
}

// WithErrorLog enables a custom error logger on the server.
func WithErrorLog(logger *log.Logger) Option {
	return func(s *Server) *Server {
		s.errorLog = logger
		return s
	}
}

// Serve starts the server on the specified listener.
func (s *Server) Serve(ln net.Listener) error {
	for {
		conn, err := ln.Accept()
		if err != nil {
			s.errorLog.Printf(
				"server: error accepting new connection on listener: err=%v",
				err,
			)
			continue
		}

		conn = &server.TimeoutConn{
			ReadTimeout:  s.connReadTimeout,
			WriteTimeout: s.connWriteTimeout,
			Conn:         conn,
		}

		go s.handle(conn)
	}
}

// handle processes the client connection.
func (s *Server) handle(conn net.Conn) {
	reader := protocol.NewReader(conn)

	// Start a loop reading and processing requests from the client, in order to support
	// connection reuse across multiple requests.
	for {
		if err := s.dispatch(conn, reader); err != nil {
			if err != io.EOF {
				s.errorLog.Printf("server: error handling connection: err=%v", err)
			}

			conn.Close()
			return
		}
	}
}

// dispatch parses the request and invokes the underlying service handler.
func (s *Server) dispatch(conn net.Conn, reader *protocol.Reader) error {
	var ctx context.Context
	var req protocol.Request
	var resp protocol.Response
	var hErr error

	buf, err := reader.ReadASCIICommand()
	if err != nil {
		return fmt.Errorf("server: error buffering command for parse: err=%v", err)
	}

	req, err = protocol.NewASCIIParser().Parse(buf)
	switch err {
	case protocol.ErrInvalidParse:
		if _, cErr := conn.Write([]byte(err.Error())); cErr != nil {
			return cErr
		}
	case nil:
		break
	default:
		return fmt.Errorf("server: error parsing command: %v", err)
	}

	switch r := req.(type) {
	case *protocol.VersionRequest:
		resp, hErr = s.handler.Version(ctx, r)
	case *protocol.ShutdownRequest:
		resp, hErr = s.handler.Shutdown(ctx, r)
	case *protocol.FlushRequest:
		resp, hErr = s.handler.Flush(ctx, r)
	case *protocol.StatsRequest:
		resp, hErr = s.handler.Stats(ctx, r)
	case *protocol.WatchRequest:
		resp, hErr = s.handler.Watch(ctx, r)
	case *protocol.TouchRequest:
		resp, hErr = s.handler.Touch(ctx, r)
	case *protocol.DeleteRequest:
		resp, hErr = s.handler.Delete(ctx, r)
	case *protocol.IncrRequest:
		resp, hErr = s.handler.Incr(ctx, r)
	case *protocol.DecrRequest:
		resp, hErr = s.handler.Decr(ctx, r)
	case *protocol.GetRequest:
		resp, hErr = s.handler.Get(ctx, r)
	case *protocol.GetsRequest:
		resp, hErr = s.handler.Gets(ctx, r)
	case *protocol.GatRequest:
		resp, hErr = s.handler.Gat(ctx, r)
	case *protocol.GatsRequest:
		resp, hErr = s.handler.Gats(ctx, r)
	case *protocol.SetRequest:
		resp, hErr = s.handler.Set(ctx, r)
	case *protocol.AddRequest:
		resp, hErr = s.handler.Add(ctx, r)
	case *protocol.ReplaceRequest:
		resp, hErr = s.handler.Replace(ctx, r)
	case *protocol.AppendRequest:
		resp, hErr = s.handler.Append(ctx, r)
	case *protocol.PrependRequest:
		resp, hErr = s.handler.Prepend(ctx, r)
	case *protocol.CasRequest:
		resp, hErr = s.handler.Cas(ctx, r)
	default:
		return fmt.Errorf("server: unsupported request type: request=%T", req)
	}

	if req.IsNoReply() {
		return nil
	}

	if hErr != nil {
		if _, cErr := conn.Write([]byte(hErr.Error())); cErr != nil {
			return cErr
		}
	} else {
		if _, cErr := conn.Write([]byte(resp.String())); cErr != nil {
			return cErr
		}
	}

	return nil
}

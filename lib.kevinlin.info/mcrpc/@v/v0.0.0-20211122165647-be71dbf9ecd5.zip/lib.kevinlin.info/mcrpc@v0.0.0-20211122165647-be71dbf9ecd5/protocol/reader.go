package protocol

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
)

var (
	// crlf is a byte sequence conventionally marking the end of a protocol message.
	crlf = []byte("\r\n")
	// storageCommands is a slice of protocol command names that are responsible for storing
	// data. These commands prefix the only messages in the protocol that terminate on the
	// second CRLF sequence, rather than the first.
	storageCommands = [][]byte{
		[]byte("set"),
		[]byte("add"),
		[]byte("replace"),
		[]byte("append"),
		[]byte("prepend"),
		[]byte("cas"),
	}
	// maxStorageHeaderSize is the upper limit on the storage header size. In practice, this is
	// the upper limit of depth the reader will scan for the header for storage protocol
	// commands.
	maxStorageHeaderSize = 64
	// maxStorageItemSize is a reasonable upper limit on the maximum supported item size
	// supported by the reader. In practice, this is the upper limit of depth the reader will
	// scan for the full data block for storage protocol commands.
	maxStorageItemSize = 10 * 1024 * 1024
)

// Reader abstracts over an io.Reader that acts as an input stream for memcache protocol commands.
type Reader struct {
	bufStream *bufio.Reader
	io.Reader
}

// NewReader creates a new protocol-aware reader from an io.Reader.
func NewReader(stream io.Reader) *Reader {
	return &Reader{
		bufStream: bufio.NewReader(stream),
		Reader:    stream,
	}
}

// ReadASCIICommand reads a full ASCII command from the underlying io.Reader, exercising heuristics
// to determine how far into the stream data should be read.
func (r *Reader) ReadASCIICommand() ([]byte, error) {
	// Check only the length of the request equal to the length of the longest storage command
	initial, err := r.bufStream.Peek(7)
	if err != nil {
		return nil, err
	}

	// Storage commands are the only protocol request messages that conclude on the second CRLF
	// sequence, which is treated as a separate case.
	for _, cmd := range storageCommands {
		if bytes.HasPrefix(initial, cmd) {
			// Header
			header, err := r.readUntil(crlf, maxStorageHeaderSize)
			if err != nil {
				return nil, err
			}

			// Body data (scan no more than 10 MB, to accommodate a 10 MB item size)
			data, err := r.readUntil(crlf, maxStorageItemSize)
			if err != nil {
				return nil, err
			}

			return append(header, data...), nil
		}
	}

	// For all other commands, consider the message to be complete upon the first CRLF.
	return r.readUntil(crlf, maxStorageItemSize)
}

// readUntil continues reading from the buffered stream until the termination sequence is
// encountered, with a finite limit on maximum forward seek length.
func (r *Reader) readUntil(sequence []byte, maxSeek int) ([]byte, error) {
	if maxSeek < len(sequence) {
		return nil, errors.New("protocol: sequence is shorter than maximum allowed seek")
	}

	buf := make([]byte, 0, maxSeek)
	scan := make([]byte, 1)

	for i := 0; i < maxSeek; i++ {
		_, err := r.bufStream.Read(scan)
		if err != nil {
			return nil, fmt.Errorf("protocol: error reading from buffered connection: err=%v", err)
		}

		buf = append(buf, scan...)

		if i >= len(sequence)-1 && bytes.Equal(buf[len(buf)-len(sequence):], sequence) {
			return buf, nil
		}
	}

	return nil, fmt.Errorf("protocol: exhausted maximum allowed seek without finding sequence")
}

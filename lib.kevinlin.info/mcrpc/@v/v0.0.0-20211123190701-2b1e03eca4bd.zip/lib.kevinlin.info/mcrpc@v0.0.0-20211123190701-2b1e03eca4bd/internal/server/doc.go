// Package server provides internal utilities for mcrpc server behaviors.
package server

// Package mcrpc provides abstractions and interfaces for building memcache-protocol servers.
package mcrpc

// Package lib provides utilities for building mcrpc servers and handlers.
package lib

// Package protocol implements a memcache ASCII protocol parser and contains utilities for reading
// protocol-compliant messages over a reader stream.
package protocol

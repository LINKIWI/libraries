// Package schemas provides generated Go code for Protobuf schemas and associated gRPC services.
package schemas

import setuptools


setuptools.setup(
    name='elementd',
    version='3879538a9689488f9ca348c3b022ec77872c49b8',
    author='elementd',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/15/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

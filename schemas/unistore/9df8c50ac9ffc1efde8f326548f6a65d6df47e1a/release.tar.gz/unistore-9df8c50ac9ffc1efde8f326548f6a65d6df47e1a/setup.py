import setuptools


setuptools.setup(
    name='unistore',
    version='9df8c50ac9ffc1efde8f326548f6a65d6df47e1a',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/28/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

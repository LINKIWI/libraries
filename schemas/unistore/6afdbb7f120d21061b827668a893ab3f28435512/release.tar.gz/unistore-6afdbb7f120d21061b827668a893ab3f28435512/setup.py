import setuptools


setuptools.setup(
    name='unistore',
    version='6afdbb7f120d21061b827668a893ab3f28435512',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/46/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

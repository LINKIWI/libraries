import setuptools


setuptools.setup(
    name='unistore',
    version='d128eda9a49634fb00ac1046ef2faf9d6c87860a',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/40/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

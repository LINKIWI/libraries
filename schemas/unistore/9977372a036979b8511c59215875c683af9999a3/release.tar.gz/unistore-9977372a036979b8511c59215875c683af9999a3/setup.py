import setuptools


setuptools.setup(
    name='unistore',
    version='9977372a036979b8511c59215875c683af9999a3',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/26/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

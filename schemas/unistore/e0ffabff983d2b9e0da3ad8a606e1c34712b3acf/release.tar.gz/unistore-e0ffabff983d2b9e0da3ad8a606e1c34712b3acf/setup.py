import setuptools


setuptools.setup(
    name='unistore',
    version='e0ffabff983d2b9e0da3ad8a606e1c34712b3acf',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/21/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

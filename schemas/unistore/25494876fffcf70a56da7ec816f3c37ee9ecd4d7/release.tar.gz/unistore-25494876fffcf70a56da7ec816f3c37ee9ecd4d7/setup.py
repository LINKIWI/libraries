import setuptools


setuptools.setup(
    name='unistore',
    version='25494876fffcf70a56da7ec816f3c37ee9ecd4d7',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/42/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

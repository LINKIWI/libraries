import setuptools


setuptools.setup(
    name='unistore',
    version='0cbbde9e4cf718a7ecf90a832ea115f16a0adb14',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/23/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

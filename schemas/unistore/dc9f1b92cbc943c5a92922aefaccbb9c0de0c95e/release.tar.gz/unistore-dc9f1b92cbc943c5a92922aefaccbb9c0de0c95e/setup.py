import setuptools


setuptools.setup(
    name='unistore',
    version='dc9f1b92cbc943c5a92922aefaccbb9c0de0c95e',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/30/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='unistore',
    version='aa7c29b20eda4cc32217e36f48f971e147237968',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/14/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='unistore',
    version='354b1147d9f569aa204c721036e32248c5ca822d',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/24/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

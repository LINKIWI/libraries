import setuptools


setuptools.setup(
    name='unistore',
    version='729f5a04e9c136cb003eefaf95dea7b4c4e315d3',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/50/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='unistore',
    version='e9a6c8daaa9a1ac926690f4209340298a628544f',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/45/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

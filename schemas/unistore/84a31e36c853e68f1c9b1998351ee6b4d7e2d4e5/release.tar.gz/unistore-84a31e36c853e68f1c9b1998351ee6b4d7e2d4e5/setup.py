import setuptools


setuptools.setup(
    name='unistore',
    version='84a31e36c853e68f1c9b1998351ee6b4d7e2d4e5',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/43/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

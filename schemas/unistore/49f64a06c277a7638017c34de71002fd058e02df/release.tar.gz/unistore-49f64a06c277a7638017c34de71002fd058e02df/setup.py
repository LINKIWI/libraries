import setuptools


setuptools.setup(
    name='unistore',
    version='49f64a06c277a7638017c34de71002fd058e02df',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/55/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

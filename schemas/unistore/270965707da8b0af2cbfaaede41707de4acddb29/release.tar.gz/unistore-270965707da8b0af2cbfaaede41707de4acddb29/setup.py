import setuptools


setuptools.setup(
    name='unistore',
    version='270965707da8b0af2cbfaaede41707de4acddb29',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/31/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

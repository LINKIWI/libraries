import setuptools


setuptools.setup(
    name='unistore',
    version='7925a0c28652ef9d5a69683faf3f7873b4ac21b9',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/29/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

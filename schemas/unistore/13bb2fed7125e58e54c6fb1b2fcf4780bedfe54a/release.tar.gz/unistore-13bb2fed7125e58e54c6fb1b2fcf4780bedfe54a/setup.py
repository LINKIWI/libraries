import setuptools


setuptools.setup(
    name='unistore',
    version='13bb2fed7125e58e54c6fb1b2fcf4780bedfe54a',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/25/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='unistore',
    version='0c38fc5c2afbe138bc19de2511b2fcb9f30771ae',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/20/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

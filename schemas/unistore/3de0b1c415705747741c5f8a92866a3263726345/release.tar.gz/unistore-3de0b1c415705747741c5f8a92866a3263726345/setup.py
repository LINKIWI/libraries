import setuptools


setuptools.setup(
    name='unistore',
    version='3de0b1c415705747741c5f8a92866a3263726345',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/48/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

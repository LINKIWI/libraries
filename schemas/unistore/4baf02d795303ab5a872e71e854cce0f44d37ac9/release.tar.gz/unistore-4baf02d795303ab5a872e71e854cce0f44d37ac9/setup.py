import setuptools


setuptools.setup(
    name='unistore',
    version='4baf02d795303ab5a872e71e854cce0f44d37ac9',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/51/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

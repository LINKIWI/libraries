import setuptools


setuptools.setup(
    name='unistore',
    version='ab68764b2b34f853c88fc0e8fc0a38b66adf1850',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/16/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='unistore',
    version='f58eb20220fcb2ab6583a915b66fe2c3927fda32',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/49/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

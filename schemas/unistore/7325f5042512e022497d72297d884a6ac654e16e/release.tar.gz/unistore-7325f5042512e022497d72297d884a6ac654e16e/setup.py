import setuptools


setuptools.setup(
    name='unistore',
    version='7325f5042512e022497d72297d884a6ac654e16e',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/22/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

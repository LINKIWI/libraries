import setuptools


setuptools.setup(
    name='unistore',
    version='3317688d46f8c2c753ec486ea78a61cddb6900c2',
    author='unistore',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/44/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='ariia',
    version='d7b1f00f81bd2ed89ce579d929d50e193aa51d00',
    author='ariia',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/19/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

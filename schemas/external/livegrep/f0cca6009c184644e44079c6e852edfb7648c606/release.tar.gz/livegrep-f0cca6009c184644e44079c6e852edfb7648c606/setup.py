import setuptools


setuptools.setup(
    name='livegrep',
    version='f0cca6009c184644e44079c6e852edfb7648c606',
    author='livegrep',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/47/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='livegrep',
    version='c62b1eae84a21d3d50e760060ba7bf52303a1814',
    author='livegrep',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/39/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

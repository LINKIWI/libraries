import setuptools


setuptools.setup(
    name='livegrep',
    version='d6b15bca7e3d879b877ab5835acfe805d07ae2af',
    author='livegrep',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/52/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='livegrep',
    version='559bc5cc628461667b88fea5a27c2b5d94076133',
    author='livegrep',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/41/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

import setuptools


setuptools.setup(
    name='livegrep',
    version='682af03433a16ddbdedbdebd7dcd522197f89663',
    author='livegrep',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/54/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)

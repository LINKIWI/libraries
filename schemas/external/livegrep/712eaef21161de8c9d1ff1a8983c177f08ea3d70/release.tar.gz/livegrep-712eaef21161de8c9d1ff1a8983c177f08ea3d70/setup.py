import setuptools


setuptools.setup(
    name='livegrep',
    version='712eaef21161de8c9d1ff1a8983c177f08ea3d70',
    author='livegrep',
    author_email='packages@kevinlin.info',
    url='https://ci.internal.kevinlin.info/job/task--schema/53/',
    packages=setuptools.find_packages(),
    install_requires=[
        'grpcio-tools==1.43.0',
    ],
)
